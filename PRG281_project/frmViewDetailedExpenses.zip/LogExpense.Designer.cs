﻿namespace Goals_PRG281_project
{
    partial class frmExpenseTracker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbExpenseCategory = new System.Windows.Forms.ComboBox();
            this.txtExpenseAmount = new System.Windows.Forms.TextBox();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.btnLogExpense = new System.Windows.Forms.Button();
            this.btnViewHistory = new System.Windows.Forms.Button();
            this.txtNotes = new System.Windows.Forms.RichTextBox();
            this.lblDateOfExspense = new System.Windows.Forms.Label();
            this.lblWxspenseamount = new System.Windows.Forms.Label();
            this.lblNote = new System.Windows.Forms.Label();
            this.lnlExspenseCategorie = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cbExpenseCategory
            // 
            this.cbExpenseCategory.FormattingEnabled = true;
            this.cbExpenseCategory.Items.AddRange(new object[] {
            "Entertainment",
            "Groceries",
            "Rent",
            "Medical"});
            this.cbExpenseCategory.Location = new System.Drawing.Point(94, 47);
            this.cbExpenseCategory.Name = "cbExpenseCategory";
            this.cbExpenseCategory.Size = new System.Drawing.Size(121, 24);
            this.cbExpenseCategory.TabIndex = 0;
            // 
            // txtExpenseAmount
            // 
            this.txtExpenseAmount.Location = new System.Drawing.Point(89, 93);
            this.txtExpenseAmount.Name = "txtExpenseAmount";
            this.txtExpenseAmount.Size = new System.Drawing.Size(100, 22);
            this.txtExpenseAmount.TabIndex = 1;
            // 
            // dtpDate
            // 
            this.dtpDate.Location = new System.Drawing.Point(94, 170);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(200, 22);
            this.dtpDate.TabIndex = 2;
            // 
            // btnLogExpense
            // 
            this.btnLogExpense.Location = new System.Drawing.Point(89, 387);
            this.btnLogExpense.Name = "btnLogExpense";
            this.btnLogExpense.Size = new System.Drawing.Size(103, 23);
            this.btnLogExpense.TabIndex = 4;
            this.btnLogExpense.Text = " Log expense";
            this.btnLogExpense.UseVisualStyleBackColor = true;
            this.btnLogExpense.Click += new System.EventHandler(this.btnLogExpense_Click_1);
            // 
            // btnViewHistory
            // 
            this.btnViewHistory.Location = new System.Drawing.Point(354, 387);
            this.btnViewHistory.Name = "btnViewHistory";
            this.btnViewHistory.Size = new System.Drawing.Size(130, 23);
            this.btnViewHistory.TabIndex = 5;
            this.btnViewHistory.Text = "view expense history";
            this.btnViewHistory.UseVisualStyleBackColor = true;
            this.btnViewHistory.Click += new System.EventHandler(this.btnViewHistory_Click_1);
            // 
            // txtNotes
            // 
            this.txtNotes.Location = new System.Drawing.Point(118, 273);
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.Size = new System.Drawing.Size(274, 96);
            this.txtNotes.TabIndex = 6;
            this.txtNotes.Text = "";
            // 
            // lblDateOfExspense
            // 
            this.lblDateOfExspense.AutoSize = true;
            this.lblDateOfExspense.Location = new System.Drawing.Point(86, 134);
            this.lblDateOfExspense.Name = "lblDateOfExspense";
            this.lblDateOfExspense.Size = new System.Drawing.Size(106, 16);
            this.lblDateOfExspense.TabIndex = 7;
            this.lblDateOfExspense.Text = "Date of Expense";
            // 
            // lblWxspenseamount
            // 
            this.lblWxspenseamount.AutoSize = true;
            this.lblWxspenseamount.Location = new System.Drawing.Point(91, 74);
            this.lblWxspenseamount.Name = "lblWxspenseamount";
            this.lblWxspenseamount.Size = new System.Drawing.Size(107, 16);
            this.lblWxspenseamount.TabIndex = 9;
            this.lblWxspenseamount.Text = "Expense amount";
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Location = new System.Drawing.Point(91, 251);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(46, 16);
            this.lblNote.TabIndex = 10;
            this.lblNote.Text = "Notes:";
            // 
            // lnlExspenseCategorie
            // 
            this.lnlExspenseCategorie.AutoSize = true;
            this.lnlExspenseCategorie.Location = new System.Drawing.Point(89, 28);
            this.lnlExspenseCategorie.Name = "lnlExspenseCategorie";
            this.lnlExspenseCategorie.Size = new System.Drawing.Size(118, 16);
            this.lnlExspenseCategorie.TabIndex = 11;
            this.lnlExspenseCategorie.Text = "Expense Category";
            // 
            // frmExpenseTracker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lnlExspenseCategorie);
            this.Controls.Add(this.lblNote);
            this.Controls.Add(this.lblWxspenseamount);
            this.Controls.Add(this.lblDateOfExspense);
            this.Controls.Add(this.txtNotes);
            this.Controls.Add(this.btnViewHistory);
            this.Controls.Add(this.btnLogExpense);
            this.Controls.Add(this.dtpDate);
            this.Controls.Add(this.txtExpenseAmount);
            this.Controls.Add(this.cbExpenseCategory);
            this.Name = "frmExpenseTracker";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmExpenseTracker_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbExpenseCategory;
        private System.Windows.Forms.TextBox txtExpenseAmount;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.Button btnLogExpense;
        private System.Windows.Forms.Button btnViewHistory;
        private System.Windows.Forms.RichTextBox txtNotes;
        private System.Windows.Forms.Label lblDateOfExspense;
        private System.Windows.Forms.Label lblWxspenseamount;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.Label lnlExspenseCategorie;
    }
}

