﻿namespace Goals_PRG281_project
{
    partial class frmCurrent_goals
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMainMenu = new System.Windows.Forms.Label();
            this.llblGoalSetting = new System.Windows.Forms.LinkLabel();
            this.lblCurrentGoals = new System.Windows.Forms.Label();
            this.btnGoalSetting = new System.Windows.Forms.Button();
            this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.lblNoGoalsyet = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMainMenu
            // 
            this.lblMainMenu.AutoSize = true;
            this.lblMainMenu.Location = new System.Drawing.Point(11, 7);
            this.lblMainMenu.Name = "lblMainMenu";
            this.lblMainMenu.Size = new System.Drawing.Size(82, 16);
            this.lblMainMenu.TabIndex = 0;
            this.lblMainMenu.Text = "Main menu >";
            // 
            // llblGoalSetting
            // 
            this.llblGoalSetting.AutoSize = true;
            this.llblGoalSetting.Location = new System.Drawing.Point(96, 7);
            this.llblGoalSetting.Name = "llblGoalSetting";
            this.llblGoalSetting.Size = new System.Drawing.Size(78, 16);
            this.llblGoalSetting.TabIndex = 1;
            this.llblGoalSetting.TabStop = true;
            this.llblGoalSetting.Text = "Goal setting";
            this.llblGoalSetting.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblGoalSetting_LinkClicked);
            // 
            // lblCurrentGoals
            // 
            this.lblCurrentGoals.AutoSize = true;
            this.lblCurrentGoals.Location = new System.Drawing.Point(175, 7);
            this.lblCurrentGoals.Name = "lblCurrentGoals";
            this.lblCurrentGoals.Size = new System.Drawing.Size(96, 16);
            this.lblCurrentGoals.TabIndex = 2;
            this.lblCurrentGoals.Text = "> Current goals";
            // 
            // btnGoalSetting
            // 
            this.btnGoalSetting.Location = new System.Drawing.Point(660, 7);
            this.btnGoalSetting.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnGoalSetting.Name = "btnGoalSetting";
            this.btnGoalSetting.Size = new System.Drawing.Size(105, 30);
            this.btnGoalSetting.TabIndex = 3;
            this.btnGoalSetting.Text = "Goal setting";
            this.btnGoalSetting.UseVisualStyleBackColor = true;
            this.btnGoalSetting.Click += new System.EventHandler(this.btnGoalSetting_Click);
            // 
            // vScrollBar1
            // 
            this.vScrollBar1.Location = new System.Drawing.Point(751, 46);
            this.vScrollBar1.Name = "vScrollBar1";
            this.vScrollBar1.Size = new System.Drawing.Size(27, 386);
            this.vScrollBar1.TabIndex = 4;
            // 
            // lblNoGoalsyet
            // 
            this.lblNoGoalsyet.AutoSize = true;
            this.lblNoGoalsyet.Location = new System.Drawing.Point(11, 23);
            this.lblNoGoalsyet.Name = "lblNoGoalsyet";
            this.lblNoGoalsyet.Size = new System.Drawing.Size(80, 16);
            this.lblNoGoalsyet.TabIndex = 5;
            this.lblNoGoalsyet.Text = "no goals yet";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.pictureBox1);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(11, 46);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(755, 380);
            this.flowLayoutPanel1.TabIndex = 7;
            this.flowLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(559, 313);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // frmCurrent_goals
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(776, 436);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.lblNoGoalsyet);
            this.Controls.Add(this.vScrollBar1);
            this.Controls.Add(this.btnGoalSetting);
            this.Controls.Add(this.lblCurrentGoals);
            this.Controls.Add(this.llblGoalSetting);
            this.Controls.Add(this.lblMainMenu);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmCurrent_goals";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Current goals";
            this.Load += new System.EventHandler(this.frmCurrent_goals_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMainMenu;
        private System.Windows.Forms.LinkLabel llblGoalSetting;
        private System.Windows.Forms.Label lblCurrentGoals;
        private System.Windows.Forms.Button btnGoalSetting;
        private System.Windows.Forms.VScrollBar vScrollBar1;
        private System.Windows.Forms.Label lblNoGoalsyet;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}