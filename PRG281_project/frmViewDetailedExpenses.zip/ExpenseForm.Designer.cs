﻿namespace Goals_PRG281_project
{
    partial class frmExpenseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lvExpenseDetails = new System.Windows.Forms.ListView();
            this.btnViewDetails = new System.Windows.Forms.Button();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.llblExistingBudget = new System.Windows.Forms.LinkLabel();
            this.llblMainMenu = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(91, 47);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(100, 22);
            this.txtSearch.TabIndex = 0;
            // 
            // lvExpenseDetails
            // 
            this.lvExpenseDetails.HideSelection = false;
            this.lvExpenseDetails.Location = new System.Drawing.Point(91, 145);
            this.lvExpenseDetails.Name = "lvExpenseDetails";
            this.lvExpenseDetails.Size = new System.Drawing.Size(636, 97);
            this.lvExpenseDetails.TabIndex = 1;
            this.lvExpenseDetails.UseCompatibleStateImageBehavior = false;
            // 
            // btnViewDetails
            // 
            this.btnViewDetails.Location = new System.Drawing.Point(91, 295);
            this.btnViewDetails.Name = "btnViewDetails";
            this.btnViewDetails.Size = new System.Drawing.Size(75, 23);
            this.btnViewDetails.TabIndex = 2;
            this.btnViewDetails.Text = "button1";
            this.btnViewDetails.UseVisualStyleBackColor = true;
            this.btnViewDetails.Click += new System.EventHandler(this.btnViewDetails_Click_1);
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.Location = new System.Drawing.Point(674, 11);
            this.btnMainMenu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(105, 30);
            this.btnMainMenu.TabIndex = 9;
            this.btnMainMenu.Text = "Main menu";
            this.btnMainMenu.UseVisualStyleBackColor = true;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(246, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "Goal setting";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // llblExistingBudget
            // 
            this.llblExistingBudget.AutoSize = true;
            this.llblExistingBudget.Location = new System.Drawing.Point(132, 9);
            this.llblExistingBudget.Name = "llblExistingBudget";
            this.llblExistingBudget.Size = new System.Drawing.Size(104, 16);
            this.llblExistingBudget.TabIndex = 12;
            this.llblExistingBudget.TabStop = true;
            this.llblExistingBudget.Text = "Track expenses";
            this.llblExistingBudget.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblExistingBudget_LinkClicked);
            // 
            // llblMainMenu
            // 
            this.llblMainMenu.AutoSize = true;
            this.llblMainMenu.Location = new System.Drawing.Point(44, 9);
            this.llblMainMenu.Name = "llblMainMenu";
            this.llblMainMenu.Size = new System.Drawing.Size(82, 16);
            this.llblMainMenu.TabIndex = 13;
            this.llblMainMenu.TabStop = true;
            this.llblMainMenu.Text = "Main menu >";
            this.llblMainMenu.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblMainMenu_LinkClicked);
            // 
            // frmExpenseForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.llblMainMenu);
            this.Controls.Add(this.llblExistingBudget);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.btnViewDetails);
            this.Controls.Add(this.lvExpenseDetails);
            this.Controls.Add(this.txtSearch);
            this.Name = "frmExpenseForm";
            this.Text = "ExpenseForm";
            this.Load += new System.EventHandler(this.frmExpenseForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.ListView lvExpenseDetails;
        private System.Windows.Forms.Button btnViewDetails;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel llblExistingBudget;
        private System.Windows.Forms.LinkLabel llblMainMenu;
    }
}