﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Goals_PRG281_project
{
 
    public partial class frmExistingBudgetScreen1 : Form
    {
        Navigation navigation = new Navigation();
        //***update lblTotIncAmount once switches to this form
        public frmExistingBudgetScreen1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

        }

        //creating our own object of the source
        BindingSource src = new BindingSource();
        List<ExpenseItem> allExpenses = new List<ExpenseItem>();

        private void lblTotIncAmount_Click(object sender, EventArgs e)
        {

        }

        private void ViewExistingBudgetScreen1_Load(object sender, EventArgs e)
        {

            //Set our source of data
            src.DataSource = allExpenses;

            //Binding data source to DataGridView
            dgvExistingBudget.DataSource = src;

            //Customize DataGridView to show specific columns
            dgvExistingBudget.Columns["CategoryName"].HeaderText = "Category";
            dgvExistingBudget.Columns["BudgetedAmount"].HeaderText = "Budgeted Amount";
            dgvExistingBudget.Columns["ActualAmount"].HeaderText = "Expenses";
            dgvExistingBudget.Columns["RemainingAmount"].HeaderText = "Remaining Budget";

            //hide columns i don't want to display
            dgvExistingBudget.Columns["Date"].Visible = false;
            dgvExistingBudget.Columns["Notes"].Visible = false;

            //Autosizeing columns
            dgvExistingBudget.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnDetailedExpenses_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                navigation.GoToDetailedExpenses();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while navigating to the main menu: " + ex.Message);
            }

        }

        private void llblMainMenu_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                this.Hide();
                navigation.GotoMainMenu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while navigating to the main menu: " + ex.Message);
            }

        }

        private void llblBudgetsetup_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           
     
        }
    }
}
