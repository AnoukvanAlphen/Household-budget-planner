﻿namespace Goals_PRG281_project
{
    partial class frmExistingBudgetScreen1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvExistingBudget = new System.Windows.Forms.DataGridView();
            this.lbltotMInc = new System.Windows.Forms.Label();
            this.lblTotIncAmount = new System.Windows.Forms.Label();
            this.lblExpenses = new System.Windows.Forms.Label();
            this.btnDetailedExpenses = new System.Windows.Forms.Button();
            this.lblExistingBudget = new System.Windows.Forms.Label();
            this.llblMainMenu = new System.Windows.Forms.LinkLabel();
            this.llblBudgetsetup = new System.Windows.Forms.LinkLabel();
            this.lblBudgetSetUp1 = new System.Windows.Forms.Label();
            this.lblR = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExistingBudget)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvExistingBudget
            // 
            this.dgvExistingBudget.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvExistingBudget.Location = new System.Drawing.Point(16, 130);
            this.dgvExistingBudget.Margin = new System.Windows.Forms.Padding(4);
            this.dgvExistingBudget.Name = "dgvExistingBudget";
            this.dgvExistingBudget.RowHeadersWidth = 51;
            this.dgvExistingBudget.Size = new System.Drawing.Size(1003, 297);
            this.dgvExistingBudget.TabIndex = 0;
            // 
            // lbltotMInc
            // 
            this.lbltotMInc.AutoSize = true;
            this.lbltotMInc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotMInc.Location = new System.Drawing.Point(12, 62);
            this.lbltotMInc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltotMInc.Name = "lbltotMInc";
            this.lbltotMInc.Size = new System.Drawing.Size(164, 20);
            this.lbltotMInc.TabIndex = 1;
            this.lbltotMInc.Text = "Total montly income:";
            // 
            // lblTotIncAmount
            // 
            this.lblTotIncAmount.AutoSize = true;
            this.lblTotIncAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotIncAmount.Location = new System.Drawing.Point(197, 62);
            this.lblTotIncAmount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotIncAmount.Name = "lblTotIncAmount";
            this.lblTotIncAmount.Size = new System.Drawing.Size(63, 20);
            this.lblTotIncAmount.TabIndex = 2;
            this.lblTotIncAmount.Text = "______";
            this.lblTotIncAmount.Click += new System.EventHandler(this.lblTotIncAmount_Click);
            // 
            // lblExpenses
            // 
            this.lblExpenses.AutoSize = true;
            this.lblExpenses.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpenses.Location = new System.Drawing.Point(16, 97);
            this.lblExpenses.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblExpenses.Name = "lblExpenses";
            this.lblExpenses.Size = new System.Drawing.Size(87, 20);
            this.lblExpenses.TabIndex = 3;
            this.lblExpenses.Text = "Expenses:";
            // 
            // btnDetailedExpenses
            // 
            this.btnDetailedExpenses.Location = new System.Drawing.Point(17, 480);
            this.btnDetailedExpenses.Name = "btnDetailedExpenses";
            this.btnDetailedExpenses.Size = new System.Drawing.Size(132, 23);
            this.btnDetailedExpenses.TabIndex = 4;
            this.btnDetailedExpenses.Text = "Detailed expenses";
            this.btnDetailedExpenses.UseVisualStyleBackColor = true;
            this.btnDetailedExpenses.Click += new System.EventHandler(this.btnDetailedExpenses_Click);
            // 
            // lblExistingBudget
            // 
            this.lblExistingBudget.AutoSize = true;
            this.lblExistingBudget.Location = new System.Drawing.Point(208, 21);
            this.lblExistingBudget.Name = "lblExistingBudget";
            this.lblExistingBudget.Size = new System.Drawing.Size(97, 16);
            this.lblExistingBudget.TabIndex = 5;
            this.lblExistingBudget.Text = "existing budget";
            this.lblExistingBudget.Click += new System.EventHandler(this.label1_Click);
            // 
            // llblMainMenu
            // 
            this.llblMainMenu.AutoSize = true;
            this.llblMainMenu.Location = new System.Drawing.Point(17, 21);
            this.llblMainMenu.Name = "llblMainMenu";
            this.llblMainMenu.Size = new System.Drawing.Size(82, 16);
            this.llblMainMenu.TabIndex = 6;
            this.llblMainMenu.TabStop = true;
            this.llblMainMenu.Text = "Main menu >";
            this.llblMainMenu.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblMainMenu_LinkClicked);
            // 
            // llblBudgetsetup
            // 
            this.llblBudgetsetup.AutoSize = true;
            this.llblBudgetsetup.Location = new System.Drawing.Point(106, 21);
            this.llblBudgetsetup.Name = "llblBudgetsetup";
            this.llblBudgetsetup.Size = new System.Drawing.Size(96, 16);
            this.llblBudgetsetup.TabIndex = 7;
            this.llblBudgetsetup.TabStop = true;
            this.llblBudgetsetup.Text = "Budget setup >";
            this.llblBudgetsetup.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblBudgetsetup_LinkClicked);
            // 
            // lblBudgetSetUp1
            // 
            this.lblBudgetSetUp1.AutoSize = true;
            this.lblBudgetSetUp1.Location = new System.Drawing.Point(958, 21);
            this.lblBudgetSetUp1.Name = "lblBudgetSetUp1";
            this.lblBudgetSetUp1.Size = new System.Drawing.Size(96, 16);
            this.lblBudgetSetUp1.TabIndex = 8;
            this.lblBudgetSetUp1.Text = "< Budget setup";
            // 
            // lblR
            // 
            this.lblR.AutoSize = true;
            this.lblR.Location = new System.Drawing.Point(183, 66);
            this.lblR.Name = "lblR";
            this.lblR.Size = new System.Drawing.Size(17, 16);
            this.lblR.TabIndex = 9;
            this.lblR.Text = "R";
            // 
            // frmExistingBudgetScreen1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.lblR);
            this.Controls.Add(this.lblBudgetSetUp1);
            this.Controls.Add(this.llblBudgetsetup);
            this.Controls.Add(this.llblMainMenu);
            this.Controls.Add(this.lblExistingBudget);
            this.Controls.Add(this.btnDetailedExpenses);
            this.Controls.Add(this.lblExpenses);
            this.Controls.Add(this.lblTotIncAmount);
            this.Controls.Add(this.lbltotMInc);
            this.Controls.Add(this.dgvExistingBudget);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExistingBudgetScreen1";
            this.Text = "Existing Budget Screen1";
            this.Load += new System.EventHandler(this.ViewExistingBudgetScreen1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvExistingBudget)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvExistingBudget;
        private System.Windows.Forms.Label lbltotMInc;
        private System.Windows.Forms.Label lblTotIncAmount;
        private System.Windows.Forms.Label lblExpenses;
        private System.Windows.Forms.Button btnDetailedExpenses;
        private System.Windows.Forms.Label lblExistingBudget;
        private System.Windows.Forms.LinkLabel llblMainMenu;
        private System.Windows.Forms.LinkLabel llblBudgetsetup;
        private System.Windows.Forms.Label lblBudgetSetUp1;
        private System.Windows.Forms.Label lblR;
    }
}