﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Goals_PRG281_project
{
    public partial class frmViewDetailedExpenses : Form
    {
        //PLACE HOLDERS
        private List<ExpenseItem> expenses;
        Navigation navigation = new Navigation();
        public frmViewDetailedExpenses()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            LoadExpenses();
            InitializeTabs();
        }

        private void tbEntert_Click(object sender, EventArgs e)
        {

        }

        private void LoadExpenses()
        {

        }

        private void InitializeTabs()
        {
            var categoryPercentages = new Dictionary<string, decimal>();
            var categoryBudgetedAmounts = new Dictionary<string, decimal>();
            var categoryRemainingAmounts = new Dictionary<string, decimal>();

            foreach (var category in expenses.Select(e => e.CategoryName).Distinct())
            {
                TabPage tabPage = new TabPage(category);
                DataGridView dataGridView = new DataGridView { Dock = DockStyle.Fill };

                var categoryExpenses = expenses.Where(e => e.CategoryName == category).ToList();
                decimal totalBudget = categoryExpenses.Sum(e => (decimal)e.BudgetedAmount);
                decimal totalSpent = categoryExpenses.Sum(e => (decimal)e.ActualAmount);
                decimal percentage = totalSpent / totalBudget * 100;
                decimal remainingAmount = totalBudget - totalSpent;

                categoryPercentages[category] = percentage;
                categoryBudgetedAmounts[category] = totalBudget;
                categoryRemainingAmounts[category] = remainingAmount;

                dataGridView.DataSource = categoryExpenses.Select(e => new
                {
                    Date = e.Date,
                    Description = e.Notes,
                    ActualAmount = e.ActualAmount
                }).ToList();

                dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                if (percentage > 100)
                {
                    dataGridView.DefaultCellStyle.ForeColor = Color.Red;
                }
                //Removing the placeholder.
                tabControl1.TabPages.Remove(tbPg1);

                tabPage.Controls.Add(dataGridView);
                tabControl1.TabPages.Add(tabPage);
            }

            // Display the percentage for the first category
            var firstCategory = categoryPercentages.Keys.First();
            txtCategoryPercentage.Text = $"{categoryPercentages[firstCategory]:0.00}%";
            lblBudgetedAmount.Text = $"{categoryBudgetedAmounts[firstCategory]:C}";
            lblRemainingAmount.Text = $"{categoryRemainingAmounts[firstCategory]:C}";

            tabControl1.SelectedIndexChanged += (sender, e) =>
            {
                if (tabControl1.SelectedTab != null)
                {
                    string selectedCategory = tabControl1.SelectedTab.Text;
                    decimal selectedPercentage = categoryPercentages[selectedCategory];
                    decimal budgetedAmount = categoryBudgetedAmounts[selectedCategory];
                    decimal remainingAmount = categoryRemainingAmounts[selectedCategory];

                    txtCategoryPercentage.Text = $"{selectedPercentage:0.00}%";
                    lblBudgetedAmount.Text = $"{budgetedAmount:C}";
                    lblRemainingAmount.Text = $"{remainingAmount:C}";
                }
            };
        }


        private void btnDelete_Click(object sender, EventArgs e)
        {
            //Delete selected expense item from the selected category
            if (tabControl1.SelectedTab != null)
            {
                var selectedCategory = tabControl1.SelectedTab.Text;
                var dataGridView = (DataGridView)tabControl1.SelectedTab.Controls[0];

                if (dataGridView.SelectedRows.Count > 0)
                {
                    //Get the selected row
                    var selectedRow = dataGridView.SelectedRows[0];
                    var description = selectedRow.Cells["Description"].Value.ToString();

                    //Find and remove the expense item from the list
                    var expenseToRemove = expenses.FirstOrDefault(expense => expense.CategoryName == selectedCategory && expense.Notes == description);
                    if (expenseToRemove != null)
                    {
                        expenses.Remove(expenseToRemove);
                    }

                    //Clear existing tabs before updating
                    tabControl1.TabPages.Clear();

                    //Update the tabs to reflect the removal
                    InitializeTabs();
                }
                else
                {
                    MessageBox.Show("Please select an expense to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }


        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab != null && !string.IsNullOrWhiteSpace(txtNotes.Text))
            {
                var selectedCategory = tabControl1.SelectedTab.Text;
                var dataGridView = (DataGridView)tabControl1.SelectedTab.Controls[0];

                if (dataGridView.SelectedRows.Count > 0)
                {
                    var selectedRow = dataGridView.SelectedRows[0];
                    var description = selectedRow.Cells["Description"].Value.ToString();

                    //Find the expense item to edit
                    var expenseToEdit = expenses.FirstOrDefault(expense => expense.Notes == description);
                    if (expenseToEdit != null)
                    {
                        //Update the expense item
                        if (decimal.TryParse(txtActualAmount.Text, out var actual))
                        {
                            expenseToEdit.ActualAmount = (double)actual; // Convert decimal to double
                        }
                        else
                        {
                            MessageBox.Show("Invalid amount entered. Please enter a valid number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return; //Exit if the input is invalid
                        }

                        expenseToEdit.Notes = txtNotes.Text;

                        //Recalculate remaining amount
                        expenseToEdit.RemainingAmount = expenseToEdit.BudgetedAmount - expenseToEdit.ActualAmount;

                        //Clear existing tabs before updating
                        tabControl1.TabPages.Clear();

                        //Refresh the tabs to reflect changes
                        InitializeTabs();
                    }
                }
            }


        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmViewDetailedExpenses_Load(object sender, EventArgs e)
        {

        }

        private void txtCategoryPercentage_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void lblPerSpent_Click(object sender, EventArgs e)
        {

        }

        private void llblMainMenu_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                this.Hide();
                navigation.GotoMainMenu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while navigating to the main menu: " + ex.Message);
            }
        }

        private void llblBudgetsetup_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void llblExistingBudget_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                this.Hide();
                navigation.GotoExistingBudget();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while navigating to the main menu: " + ex.Message);
            }
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                navigation.GotoMainMenu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while navigating to the main menu: " + ex.Message);
            }
        }

        private void llblExistingBudget_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
    }


}