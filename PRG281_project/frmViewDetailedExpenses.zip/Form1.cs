﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Goals_PRG281_project
{
    public partial class frmSplashScreen : Form
    {
        public frmSplashScreen()
        {
            InitializeComponent();
            //test
            frmExistingBudgetScreen1 frmExistingBudgetScreen1 = new frmExistingBudgetScreen1();
            frmExistingBudgetScreen1.ShowDialog();
            frmViewDetailedExpenses viewDetailedExpenses = new frmViewDetailedExpenses();
            viewDetailedExpenses.ShowDialog();
            this.StartPosition = FormStartPosition.CenterScreen;
        }



        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void progrBarSS_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            pnlProgresssBarForground.Width += 5;
            
            timer1.Start();

            if(pnlProgresssBarForground.Width >= 763)
            {
                timer1.Stop();
                //form swith here
                
            }


        }

        private void frmSplashScreen_Load(object sender, EventArgs e)
        {

        }
    }


}
