﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Windows.Forms;
using System;

namespace Goals_PRG281_project
{
    public partial class frmBudgetSetup : Form
    {
        public static List<BudgetDetails> BudgetDetails { get; private set; } = new List<BudgetDetails>();
        Navigation navigation = new Navigation();

        public frmBudgetSetup()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void frmBudgetSetup_Load(object sender, EventArgs e)
        {
            // Add more sample data if needed
        }

        private void AddExpenses()
        {
            double monthlyIncome = 0;

            // Validate and parse monthly income
            if (!double.TryParse(txtIncome.Text.Replace("R", "").Trim(), out monthlyIncome))
            {
                MessageBox.Show("Please enter a valid monthly income.", "Invalid Value", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Check each category and create BudgetDetails objects
            if (chkRent.Checked && double.TryParse(txtRentBudget.Text.Trim(), out double rentBudget))
            {
                AddExpense("Rent", (decimal)rentBudget);
            }
            if (chkGroceries.Checked && double.TryParse(txtGroceriesBudget.Text.Trim(), out double groceriesBudget))
            {
                AddExpense("Groceries", (decimal)groceriesBudget);
            }
            if (chkEntertainment.Checked && double.TryParse(txtEntertainmentBudget.Text.Trim(), out double entertainmentBudget))
            {
                AddExpense("Entertainment", (decimal)entertainmentBudget);
            }
            if (chkMedical.Checked && double.TryParse(txtMedicalBudget.Text.Trim(), out double medicalBudget))
            {
                AddExpense("Medical", (decimal)medicalBudget);
            }
            if (chkOther.Checked && double.TryParse(txtOtherBudget.Text.Trim(), out double otherBudget))
            {
                AddExpense("Other", (decimal)otherBudget);
            }

            MessageBox.Show("Budget setup completed successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void AddExpense(string category, decimal budgetedAmount)
        {
            BudgetDetails expense = new BudgetDetails(category, budgetedAmount);
            BudgetDetails.Add(expense);
        }

        private void txtIncome_Validating(object sender, CancelEventArgs e)
        {
            // Allow income textbox to only be in currency format
            string value = txtIncome.Text;
            NumberStyles style = NumberStyles.Number | NumberStyles.AllowCurrencySymbol;
            CultureInfo culture = CultureInfo.CreateSpecificCulture("en-SA");
            decimal currency;

            if (!decimal.TryParse(value, style, culture, out currency))
            {
                MessageBox.Show("Please enter a valid amount.", "Invalid Value", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true; // Prevents textbox from losing focus
            }
        }

        private void txtIncome_Validated(object sender, EventArgs e)
        {
            string input = txtIncome.Text.Trim();

            if (input.StartsWith("R"))
            {
                string temp = input.Replace("R", "").Trim();
                string specifier = "C";
                CultureInfo culture = CultureInfo.CreateSpecificCulture("en-SA");
                txtIncome.Text = decimal.Parse(temp).ToString(specifier, culture);
            }
        }

        private void btnBudgetView_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                navigation.GotoExistingBudget();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while navigating to the main menu: " + ex.Message);
            }
        }

        private void lblkMenu_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                this.Hide();
                navigation.GotoMainMenu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while navigating to the main menu: " + ex.Message);
            }
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                navigation.GotoMainMenu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while navigating to the main menu: " + ex.Message);
            }
        }

        private void btnSubmit_Click_1(object sender, EventArgs e)
        {
            AddExpenses();
        }
    }
}
