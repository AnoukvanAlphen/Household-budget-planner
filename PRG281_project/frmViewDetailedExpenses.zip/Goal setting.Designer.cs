﻿namespace Goals_PRG281_project
{
    partial class frmGoal_setting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblGoalName = new System.Windows.Forms.Label();
            this.lblTargetAmount = new System.Windows.Forms.Label();
            this.pnlSetGoal = new System.Windows.Forms.Panel();
            this.dtDeadline = new System.Windows.Forms.DateTimePicker();
            this.txtTargetAmount = new System.Windows.Forms.TextBox();
            this.txtGoalName = new System.Windows.Forms.TextBox();
            this.Deadline = new System.Windows.Forms.Label();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.btnSaveGoal = new System.Windows.Forms.Button();
            this.btnViewGoals = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.llblGotoBudget = new System.Windows.Forms.LinkLabel();
            this.llblMainMenu = new System.Windows.Forms.LinkLabel();
            this.lblCurrentScreen = new System.Windows.Forms.Label();
            this.pnlSetGoal.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblGoalName
            // 
            this.lblGoalName.AutoSize = true;
            this.lblGoalName.Location = new System.Drawing.Point(17, 21);
            this.lblGoalName.Name = "lblGoalName";
            this.lblGoalName.Size = new System.Drawing.Size(108, 16);
            this.lblGoalName.TabIndex = 0;
            this.lblGoalName.Text = "Enter goal name:";
            // 
            // lblTargetAmount
            // 
            this.lblTargetAmount.AutoSize = true;
            this.lblTargetAmount.Location = new System.Drawing.Point(17, 78);
            this.lblTargetAmount.Name = "lblTargetAmount";
            this.lblTargetAmount.Size = new System.Drawing.Size(114, 16);
            this.lblTargetAmount.TabIndex = 1;
            this.lblTargetAmount.Text = "Set target amount:";
            // 
            // pnlSetGoal
            // 
            this.pnlSetGoal.Controls.Add(this.dtDeadline);
            this.pnlSetGoal.Controls.Add(this.txtTargetAmount);
            this.pnlSetGoal.Controls.Add(this.txtGoalName);
            this.pnlSetGoal.Controls.Add(this.Deadline);
            this.pnlSetGoal.Controls.Add(this.lblGoalName);
            this.pnlSetGoal.Controls.Add(this.lblTargetAmount);
            this.pnlSetGoal.Location = new System.Drawing.Point(22, 62);
            this.pnlSetGoal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlSetGoal.Name = "pnlSetGoal";
            this.pnlSetGoal.Size = new System.Drawing.Size(307, 202);
            this.pnlSetGoal.TabIndex = 2;
            // 
            // dtDeadline
            // 
            this.dtDeadline.Location = new System.Drawing.Point(20, 151);
            this.dtDeadline.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtDeadline.Name = "dtDeadline";
            this.dtDeadline.Size = new System.Drawing.Size(192, 22);
            this.dtDeadline.TabIndex = 3;
            // 
            // txtTargetAmount
            // 
            this.txtTargetAmount.Location = new System.Drawing.Point(20, 96);
            this.txtTargetAmount.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTargetAmount.Name = "txtTargetAmount";
            this.txtTargetAmount.Size = new System.Drawing.Size(168, 22);
            this.txtTargetAmount.TabIndex = 5;
            // 
            // txtGoalName
            // 
            this.txtGoalName.Location = new System.Drawing.Point(20, 39);
            this.txtGoalName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtGoalName.Name = "txtGoalName";
            this.txtGoalName.Size = new System.Drawing.Size(168, 22);
            this.txtGoalName.TabIndex = 4;
            // 
            // Deadline
            // 
            this.Deadline.AutoSize = true;
            this.Deadline.Location = new System.Drawing.Point(17, 133);
            this.Deadline.Name = "Deadline";
            this.Deadline.Size = new System.Drawing.Size(86, 16);
            this.Deadline.TabIndex = 3;
            this.Deadline.Text = "Set deadline:";
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.Location = new System.Drawing.Point(657, 10);
            this.btnMainMenu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(105, 30);
            this.btnMainMenu.TabIndex = 3;
            this.btnMainMenu.Text = "Main menu";
            this.btnMainMenu.UseVisualStyleBackColor = true;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            // 
            // btnSaveGoal
            // 
            this.btnSaveGoal.Location = new System.Drawing.Point(3, 51);
            this.btnSaveGoal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSaveGoal.Name = "btnSaveGoal";
            this.btnSaveGoal.Size = new System.Drawing.Size(105, 30);
            this.btnSaveGoal.TabIndex = 4;
            this.btnSaveGoal.Text = "Save goal";
            this.btnSaveGoal.UseVisualStyleBackColor = true;
            this.btnSaveGoal.Click += new System.EventHandler(this.btnSaveGoal_Click);
            // 
            // btnViewGoals
            // 
            this.btnViewGoals.Location = new System.Drawing.Point(3, 86);
            this.btnViewGoals.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnViewGoals.Name = "btnViewGoals";
            this.btnViewGoals.Size = new System.Drawing.Size(156, 30);
            this.btnViewGoals.TabIndex = 5;
            this.btnViewGoals.Text = "View current goals";
            this.btnViewGoals.UseVisualStyleBackColor = true;
            this.btnViewGoals.Click += new System.EventHandler(this.btnViewGoals_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.llblGotoBudget);
            this.panel1.Controls.Add(this.btnViewGoals);
            this.panel1.Controls.Add(this.btnSaveGoal);
            this.panel1.Location = new System.Drawing.Point(22, 269);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(212, 122);
            this.panel1.TabIndex = 6;
            // 
            // llblGotoBudget
            // 
            this.llblGotoBudget.AutoSize = true;
            this.llblGotoBudget.Location = new System.Drawing.Point(3, 22);
            this.llblGotoBudget.Name = "llblGotoBudget";
            this.llblGotoBudget.Size = new System.Drawing.Size(84, 16);
            this.llblGotoBudget.TabIndex = 6;
            this.llblGotoBudget.TabStop = true;
            this.llblGotoBudget.Text = "Go to budget";
            // 
            // llblMainMenu
            // 
            this.llblMainMenu.AutoSize = true;
            this.llblMainMenu.Location = new System.Drawing.Point(11, 7);
            this.llblMainMenu.Name = "llblMainMenu";
            this.llblMainMenu.Size = new System.Drawing.Size(72, 16);
            this.llblMainMenu.TabIndex = 7;
            this.llblMainMenu.TabStop = true;
            this.llblMainMenu.Text = "Main menu";
            this.llblMainMenu.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblMainMenu_LinkClicked);
            // 
            // lblCurrentScreen
            // 
            this.lblCurrentScreen.AutoSize = true;
            this.lblCurrentScreen.Location = new System.Drawing.Point(89, 7);
            this.lblCurrentScreen.Name = "lblCurrentScreen";
            this.lblCurrentScreen.Size = new System.Drawing.Size(88, 16);
            this.lblCurrentScreen.TabIndex = 6;
            this.lblCurrentScreen.Text = "> Goal setting";
            // 
            // frmGoal_setting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(776, 436);
            this.Controls.Add(this.lblCurrentScreen);
            this.Controls.Add(this.llblMainMenu);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.pnlSetGoal);
            this.HelpButton = true;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmGoal_setting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Goal setting";
            this.Load += new System.EventHandler(this.frmGoal_setting_Load_1);
            this.pnlSetGoal.ResumeLayout(false);
            this.pnlSetGoal.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblGoalName;
        private System.Windows.Forms.Label lblTargetAmount;
        private System.Windows.Forms.Panel pnlSetGoal;
        private System.Windows.Forms.TextBox txtGoalName;
        private System.Windows.Forms.Label Deadline;
        private System.Windows.Forms.TextBox txtTargetAmount;
        private System.Windows.Forms.DateTimePicker dtDeadline;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Button btnSaveGoal;
        private System.Windows.Forms.Button btnViewGoals;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.LinkLabel llblGotoBudget;
        private System.Windows.Forms.LinkLabel llblMainMenu;
        private System.Windows.Forms.Label lblCurrentScreen;
    }
}