﻿namespace Goals_PRG281_project
{
    partial class frmViewDetailedExpenses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.llblBudgetsetup = new System.Windows.Forms.LinkLabel();
            this.llblMainMenu = new System.Windows.Forms.LinkLabel();
            this.llblExistingBudget = new System.Windows.Forms.LinkLabel();
            this.lblDetailedExpenses = new System.Windows.Forms.Label();
            this.lblExistingBudget = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tbPg1 = new System.Windows.Forms.TabPage();
            this.txtActualAmount = new System.Windows.Forms.TextBox();
            this.txtNotes = new System.Windows.Forms.TextBox();
            this.lblActAmt = new System.Windows.Forms.Label();
            this.lblNotes = new System.Windows.Forms.Label();
            this.lblPerSpent = new System.Windows.Forms.Label();
            this.txtCategoryPercentage = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblBudgetedAmount = new System.Windows.Forms.Label();
            this.lblRemainingAmount = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(520, 490);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(4);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(100, 28);
            this.btnEdit.TabIndex = 1;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(881, 493);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(112, 28);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // llblBudgetsetup
            // 
            this.llblBudgetsetup.AutoSize = true;
            this.llblBudgetsetup.Location = new System.Drawing.Point(110, 25);
            this.llblBudgetsetup.Name = "llblBudgetsetup";
            this.llblBudgetsetup.Size = new System.Drawing.Size(96, 16);
            this.llblBudgetsetup.TabIndex = 10;
            this.llblBudgetsetup.TabStop = true;
            this.llblBudgetsetup.Text = "Budget setup >";
            // 
            // llblMainMenu
            // 
            this.llblMainMenu.AutoSize = true;
            this.llblMainMenu.Location = new System.Drawing.Point(22, 25);
            this.llblMainMenu.Name = "llblMainMenu";
            this.llblMainMenu.Size = new System.Drawing.Size(82, 16);
            this.llblMainMenu.TabIndex = 9;
            this.llblMainMenu.TabStop = true;
            this.llblMainMenu.Text = "Main menu >";
            this.llblMainMenu.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblMainMenu_LinkClicked);
            // 
            // llblExistingBudget
            // 
            this.llblExistingBudget.AutoSize = true;
            this.llblExistingBudget.Location = new System.Drawing.Point(212, 25);
            this.llblExistingBudget.Name = "llblExistingBudget";
            this.llblExistingBudget.Size = new System.Drawing.Size(108, 16);
            this.llblExistingBudget.TabIndex = 11;
            this.llblExistingBudget.TabStop = true;
            this.llblExistingBudget.Text = "Existing budget >";
            this.llblExistingBudget.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblExistingBudget_LinkClicked_1);
            // 
            // lblDetailedExpenses
            // 
            this.lblDetailedExpenses.AutoSize = true;
            this.lblDetailedExpenses.Location = new System.Drawing.Point(326, 25);
            this.lblDetailedExpenses.Name = "lblDetailedExpenses";
            this.lblDetailedExpenses.Size = new System.Drawing.Size(118, 16);
            this.lblDetailedExpenses.TabIndex = 12;
            this.lblDetailedExpenses.Text = "detailed expenses";
            // 
            // lblExistingBudget
            // 
            this.lblExistingBudget.AutoSize = true;
            this.lblExistingBudget.Location = new System.Drawing.Point(935, 25);
            this.lblExistingBudget.Name = "lblExistingBudget";
            this.lblExistingBudget.Size = new System.Drawing.Size(108, 16);
            this.lblExistingBudget.TabIndex = 13;
            this.lblExistingBudget.Text = "< Existing budget";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tbPg1);
            this.tabControl1.Location = new System.Drawing.Point(21, 135);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(963, 271);
            this.tabControl1.TabIndex = 14;
            // 
            // tbPg1
            // 
            this.tbPg1.Location = new System.Drawing.Point(4, 25);
            this.tbPg1.Name = "tbPg1";
            this.tbPg1.Padding = new System.Windows.Forms.Padding(3);
            this.tbPg1.Size = new System.Drawing.Size(955, 242);
            this.tbPg1.TabIndex = 0;
            this.tbPg1.Text = "place holder";
            this.tbPg1.UseVisualStyleBackColor = true;
            // 
            // txtActualAmount
            // 
            this.txtActualAmount.Location = new System.Drawing.Point(115, 490);
            this.txtActualAmount.Name = "txtActualAmount";
            this.txtActualAmount.Size = new System.Drawing.Size(100, 22);
            this.txtActualAmount.TabIndex = 17;
            // 
            // txtNotes
            // 
            this.txtNotes.Location = new System.Drawing.Point(356, 490);
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.Size = new System.Drawing.Size(112, 22);
            this.txtNotes.TabIndex = 18;
            // 
            // lblActAmt
            // 
            this.lblActAmt.AutoSize = true;
            this.lblActAmt.Location = new System.Drawing.Point(18, 493);
            this.lblActAmt.Name = "lblActAmt";
            this.lblActAmt.Size = new System.Drawing.Size(91, 16);
            this.lblActAmt.TabIndex = 21;
            this.lblActAmt.Text = "Actual amount";
            // 
            // lblNotes
            // 
            this.lblNotes.AutoSize = true;
            this.lblNotes.Location = new System.Drawing.Point(235, 493);
            this.lblNotes.Name = "lblNotes";
            this.lblNotes.Size = new System.Drawing.Size(115, 16);
            this.lblNotes.TabIndex = 22;
            this.lblNotes.Text = "Notes/Description";
            // 
            // lblPerSpent
            // 
            this.lblPerSpent.AutoSize = true;
            this.lblPerSpent.Location = new System.Drawing.Point(796, 86);
            this.lblPerSpent.Name = "lblPerSpent";
            this.lblPerSpent.Size = new System.Drawing.Size(119, 16);
            this.lblPerSpent.TabIndex = 23;
            this.lblPerSpent.Text = "Percentage spent :";
            // 
            // txtCategoryPercentage
            // 
            this.txtCategoryPercentage.AutoSize = true;
            this.txtCategoryPercentage.Location = new System.Drawing.Point(921, 86);
            this.txtCategoryPercentage.Name = "txtCategoryPercentage";
            this.txtCategoryPercentage.Size = new System.Drawing.Size(63, 16);
            this.txtCategoryPercentage.TabIndex = 24;
            this.txtCategoryPercentage.Text = "________";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(401, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 16);
            this.label1.TabIndex = 25;
            this.label1.Text = "Budgeted Amount :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(609, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 16);
            this.label2.TabIndex = 26;
            this.label2.Text = "Amount remaining :";
            // 
            // lblBudgetedAmount
            // 
            this.lblBudgetedAmount.AutoSize = true;
            this.lblBudgetedAmount.Location = new System.Drawing.Point(540, 86);
            this.lblBudgetedAmount.Name = "lblBudgetedAmount";
            this.lblBudgetedAmount.Size = new System.Drawing.Size(63, 16);
            this.lblBudgetedAmount.TabIndex = 27;
            this.lblBudgetedAmount.Text = "________";
            // 
            // lblRemainingAmount
            // 
            this.lblRemainingAmount.AutoSize = true;
            this.lblRemainingAmount.Location = new System.Drawing.Point(727, 86);
            this.lblRemainingAmount.Name = "lblRemainingAmount";
            this.lblRemainingAmount.Size = new System.Drawing.Size(63, 16);
            this.lblRemainingAmount.TabIndex = 28;
            this.lblRemainingAmount.Text = "________";
            // 
            // frmViewDetailedExpenses
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.lblRemainingAmount);
            this.Controls.Add(this.lblBudgetedAmount);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCategoryPercentage);
            this.Controls.Add(this.lblPerSpent);
            this.Controls.Add(this.lblNotes);
            this.Controls.Add(this.lblActAmt);
            this.Controls.Add(this.txtNotes);
            this.Controls.Add(this.txtActualAmount);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.lblExistingBudget);
            this.Controls.Add(this.lblDetailedExpenses);
            this.Controls.Add(this.llblExistingBudget);
            this.Controls.Add(this.llblBudgetsetup);
            this.Controls.Add(this.llblMainMenu);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmViewDetailedExpenses";
            this.Text = "Detailed Expenses";
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.LinkLabel llblBudgetsetup;
        private System.Windows.Forms.LinkLabel llblMainMenu;
        private System.Windows.Forms.LinkLabel llblExistingBudget;
        private System.Windows.Forms.Label lblDetailedExpenses;
        private System.Windows.Forms.Label lblExistingBudget;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tbPg1;
        private System.Windows.Forms.TextBox txtActualAmount;
        private System.Windows.Forms.TextBox txtNotes;
        private System.Windows.Forms.Label lblActAmt;
        private System.Windows.Forms.Label lblNotes;
        private System.Windows.Forms.Label lblPerSpent;
        private System.Windows.Forms.Label txtCategoryPercentage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblBudgetedAmount;
        private System.Windows.Forms.Label lblRemainingAmount;
    }
}