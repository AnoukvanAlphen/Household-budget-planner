﻿namespace PROJECTPAIN
{
    partial class frmLp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnLp = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.rtxtDisplay = new System.Windows.Forms.RichTextBox();
            this.txtCalorie = new System.Windows.Forms.TextBox();
            this.txtProtein = new System.Windows.Forms.TextBox();
            this.txtCarbohydrate = new System.Windows.Forms.TextBox();
            this.txtFat = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.pnlInput = new System.Windows.Forms.Panel();
            this.llblMainMenu = new System.Windows.Forms.LinkLabel();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.lblDetailedExpenses = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnLp
            // 
            this.btnLp.Location = new System.Drawing.Point(599, 393);
            this.btnLp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLp.Name = "btnLp";
            this.btnLp.Size = new System.Drawing.Size(133, 23);
            this.btnLp.TabIndex = 0;
            this.btnLp.Text = "Click to Calculate";
            this.btnLp.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLp.UseVisualStyleBackColor = true;
            this.btnLp.Click += new System.EventHandler(this.btnLp_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(83, 254);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "lblCalorie";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(83, 284);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "lblProtein";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(83, 320);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "lblCarbohydrate";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(83, 352);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "lblFat";
            // 
            // rtxtDisplay
            // 
            this.rtxtDisplay.Location = new System.Drawing.Point(584, 219);
            this.rtxtDisplay.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rtxtDisplay.Name = "rtxtDisplay";
            this.rtxtDisplay.Size = new System.Drawing.Size(177, 168);
            this.rtxtDisplay.TabIndex = 5;
            this.rtxtDisplay.Text = "";
            // 
            // txtCalorie
            // 
            this.txtCalorie.Location = new System.Drawing.Point(192, 250);
            this.txtCalorie.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCalorie.Name = "txtCalorie";
            this.txtCalorie.Size = new System.Drawing.Size(100, 22);
            this.txtCalorie.TabIndex = 6;
            // 
            // txtProtein
            // 
            this.txtProtein.Location = new System.Drawing.Point(192, 284);
            this.txtProtein.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtProtein.Name = "txtProtein";
            this.txtProtein.Size = new System.Drawing.Size(100, 22);
            this.txtProtein.TabIndex = 7;
            // 
            // txtCarbohydrate
            // 
            this.txtCarbohydrate.Location = new System.Drawing.Point(192, 318);
            this.txtCarbohydrate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCarbohydrate.Name = "txtCarbohydrate";
            this.txtCarbohydrate.Size = new System.Drawing.Size(100, 22);
            this.txtCarbohydrate.TabIndex = 8;
            // 
            // txtFat
            // 
            this.txtFat.Location = new System.Drawing.Point(192, 352);
            this.txtFat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtFat.Name = "txtFat";
            this.txtFat.Size = new System.Drawing.Size(100, 22);
            this.txtFat.TabIndex = 9;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // pnlInput
            // 
            this.pnlInput.Location = new System.Drawing.Point(59, 225);
            this.pnlInput.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlInput.Name = "pnlInput";
            this.pnlInput.Size = new System.Drawing.Size(263, 169);
            this.pnlInput.TabIndex = 11;
            // 
            // llblMainMenu
            // 
            this.llblMainMenu.AutoSize = true;
            this.llblMainMenu.Location = new System.Drawing.Point(56, 42);
            this.llblMainMenu.Name = "llblMainMenu";
            this.llblMainMenu.Size = new System.Drawing.Size(82, 16);
            this.llblMainMenu.TabIndex = 14;
            this.llblMainMenu.TabStop = true;
            this.llblMainMenu.Text = "Main menu >";
            this.llblMainMenu.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblMainMenu_LinkClicked);
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.Location = new System.Drawing.Point(627, 42);
            this.btnMainMenu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(105, 30);
            this.btnMainMenu.TabIndex = 30;
            this.btnMainMenu.Text = "Main menu";
            this.btnMainMenu.UseVisualStyleBackColor = true;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            // 
            // lblDetailedExpenses
            // 
            this.lblDetailedExpenses.AutoSize = true;
            this.lblDetailedExpenses.Location = new System.Drawing.Point(144, 42);
            this.lblDetailedExpenses.Name = "lblDetailedExpenses";
            this.lblDetailedExpenses.Size = new System.Drawing.Size(91, 16);
            this.lblDetailedExpenses.TabIndex = 31;
            this.lblDetailedExpenses.Text = "Optimizeation ";
            this.lblDetailedExpenses.Click += new System.EventHandler(this.lblDetailedExpenses_Click);
            // 
            // frmLp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblDetailedExpenses);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.llblMainMenu);
            this.Controls.Add(this.txtFat);
            this.Controls.Add(this.txtCarbohydrate);
            this.Controls.Add(this.txtProtein);
            this.Controls.Add(this.txtCalorie);
            this.Controls.Add(this.rtxtDisplay);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnLp);
            this.Controls.Add(this.pnlInput);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmLp";
            this.Text = "frmLp";
            this.Load += new System.EventHandler(this.frmLp_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox rtxtDisplay;
        private System.Windows.Forms.TextBox txtCalorie;
        private System.Windows.Forms.TextBox txtProtein;
        private System.Windows.Forms.TextBox txtCarbohydrate;
        private System.Windows.Forms.TextBox txtFat;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Panel pnlInput;
        private System.Windows.Forms.LinkLabel llblMainMenu;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Label lblDetailedExpenses;
    }
}